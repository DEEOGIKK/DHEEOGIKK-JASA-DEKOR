<?php
    $nama = $_POST["nama"];
    $number = $_POST["num"];
    $location = $_POST["loc"];
    $date = $_POST["date"];

    $con = new mysqli("localhost", "root", "", "dekorasi");
    if($con->connect_error) {
        die($con->connect_error);
    }else {
        $stmt = $con->prepare("INSERT INTO `cust`(`nama`, `tlp`, `location`, `date`) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $nama, $number, $location, $date);
        $stmt->execute();
        $stmt->close();
        $con->close();
    }
?>

<script>
    window.onload = function() {
        window.location.href="/thanks.html";
    }
</script>